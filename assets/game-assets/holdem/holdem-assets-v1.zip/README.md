# Hold'em asset bundle v1

홀덤 게임의 다운로드 에셋 원본 묶음이다. Flutter `pubspec.yaml`에는 등록하지 않으며,
신작 게임 코드와 패치 번호가 확정된 뒤 Firebase Storage의 아래 구조로 올린다.

```text
game-assets/holdem/manifest.json
game-assets/holdem/1/<logicalPath>
```

`inventory.json`은 디자인 산출물 검수용 파일 목록이고, `manifest.json`은 앱의
다운로드·SHA-256 검증에 사용하는 런타임 목록이다. 현재 코드는 정식 빌드와 이후
패치 모두에서 사용할 수 있도록 최소 패치 번호를 `0`으로 둔다. 배포 리허설에서 더
높은 Shorebird 패치가 필요해지면 Storage 업로드 전에 이 값만 올린다.

## 구성

- `1/images/background/tablet.webp`: 태블릿용 4:3 딥그린 게임 배경
- `1/images/background/phone.webp`: 휴대폰용 9:16 딥그린 게임 배경
- `1/images/layout/table.webp`: 자리 배치 애니메이션용 탑뷰 테이블
- `1/images/layout/chair.webp`: 자리 배치 애니메이션용 탑뷰 의자
- `1/images/cards/tablet/`: 태블릿용 정대칭 카드 52장과 클래식 별·다이아 패턴 뒷면
- `1/images/cards/phone/`: 휴대폰용 비대칭 카드 52장과 클래식 별·다이아 패턴 뒷면

카드 파일은 `suit/rank.webp` 형식이다. suit는 `spades`, `hearts`, `diamonds`,
`clubs`, rank는 `a`, `2`–`10`, `j`, `q`, `k`를 사용한다.

기존 좌석 좌표나 자리 배치 코드는 이 작업에서 변경하지 않았다. `table.webp`와
`chair.webp`만 기존 배치 로직에 연결할 수 있는 독립 투명 에셋으로 제공한다.

`holdem-assets-v1.zip`에는 이 README, `inventory.json`, `manifest.json`, 버전 `1`
디렉터리가 들어 있다.
