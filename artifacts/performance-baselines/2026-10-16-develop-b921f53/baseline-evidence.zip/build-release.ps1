$ErrorActionPreference = 'Stop'
$baselineDir = 'C:/workspace/git/project00/build/performance-baselines/2026-10-16-develop-b921f53'
$repositoryRoot = 'C:/workspace/git/project00'
$expectedCommit = 'b921f53bfb73c4b5f37c883d4285e1bb9ffcf393'
Set-Location -LiteralPath $repositoryRoot
if ((& git rev-parse HEAD).Trim() -ne $expectedCommit) {
    throw 'HEAD changed before the baseline build.'
}
$before = Get-Content -LiteralPath (Join-Path $baselineDir 'source-snapshot-before.json') -Raw | ConvertFrom-Json
foreach ($entry in $before) {
    if ((Get-FileHash -LiteralPath $entry.path -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.sha256) {
        throw "Source changed before the baseline build: $($entry.path)"
    }
}
$started = [DateTimeOffset]::UtcNow
$watch = [Diagnostics.Stopwatch]::StartNew()
$stdoutPath = Join-Path $baselineDir 'build.stdout.log'
$stderrPath = Join-Path $baselineDir 'build.stderr.log'
# Use the same Flutter-backed release assembly with an explicit exclusion for
# the Crashlytics mapping upload finalizer. This is a local baseline, not a
# production upload. Product sources and Gradle configuration stay unchanged.
$localProperties = Join-Path $repositoryRoot 'android/local.properties'
Copy-Item -LiteralPath $localProperties -Destination (Join-Path $baselineDir 'local.properties.before')
$localText = [IO.File]::ReadAllText($localProperties)
$localText = $localText -replace '(?m)^flutter\.buildMode=.*$', 'flutter.buildMode=release'
$localText = $localText -replace '(?m)^flutter\.versionName=.*$', 'flutter.versionName=1.0.0'
$localText = $localText -replace '(?m)^flutter\.versionCode=.*$', 'flutter.versionCode=4'
[IO.File]::WriteAllText($localProperties, $localText, [Text.UTF8Encoding]::new($false))
$command = '.\android\gradlew.bat -p android -q -Ptarget-platform=android-arm,android-arm64,android-x64 -Ptarget=lib/main.dart -Pbase-application-name=android.app.Application -Pdart-obfuscation=false -Ptrack-widget-creation=false -Ptree-shake-icons=true :app:assembleRelease -x :app:uploadCrashlyticsMappingFileRelease'
$process = Start-Process -FilePath $env:ComSpec -ArgumentList @('/d', '/c', $command) -WorkingDirectory $repositoryRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput $stdoutPath -RedirectStandardError $stderrPath
$timedOut = $false
$nextProgress = 30
while (-not $process.WaitForExit(1000)) {
    if ($watch.Elapsed.TotalSeconds -ge 900) {
        $timedOut = $true
        $process.Kill($true)
        $process.WaitForExit()
        break
    }
    if ($watch.Elapsed.TotalSeconds -ge $nextProgress) {
        Write-Output "Release build running: $([int]$watch.Elapsed.TotalSeconds)s"
        if (Test-Path -LiteralPath $stdoutPath) { Get-Content -LiteralPath $stdoutPath -Tail 3 }
        $nextProgress += 30
    }
}
$process.Refresh()
$buildExit = if ($timedOut) { 124 } else { $process.ExitCode }
$result = [ordered]@{
    command = $command
    startedAtUtc = $started.ToString('o')
    finishedAtUtc = [DateTimeOffset]::UtcNow.ToString('o')
    durationMs = $watch.ElapsedMilliseconds
    exitCode = $buildExit
    status = if ($buildExit -eq 0) { 'PASS' } else { 'FAIL' }
    timedOut = $timedOut
    stdout = $stdoutPath
    stderr = $stderrPath
}
$result | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $baselineDir 'build-result.json') -Encoding utf8
Get-Content -LiteralPath $stdoutPath -Tail 16
Get-Content -LiteralPath $stderrPath -Tail 16
$result | ConvertTo-Json
exit $buildExit
