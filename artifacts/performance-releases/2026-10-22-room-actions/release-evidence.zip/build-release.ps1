$ErrorActionPreference = 'Stop'
$taskRoot = 'C:/workspace/git/project00'
$taskEvidence = Join-Path $taskRoot 'build/room_action_release_20261022'
Set-Location -LiteralPath $taskRoot
$taskInputs = & git -c core.quotepath=false ls-files lib packages android assets pubspec.yaml pubspec.lock shorebird.yaml
if ($LASTEXITCODE -ne 0) { throw 'Cannot capture build source inputs.' }
$taskSnapshot = @($taskInputs | ForEach-Object {
    [pscustomobject]@{path=$_;sha256=(Get-FileHash -Algorithm SHA256 -LiteralPath $_).Hash.ToLowerInvariant()}
})
$taskSnapshot | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $taskEvidence 'source-snapshot-before.json') -Encoding utf8
$taskLocal = Join-Path $taskRoot 'android/local.properties'
Copy-Item -LiteralPath $taskLocal -Destination (Join-Path $taskEvidence 'local.properties.before')
$taskLocalText = [IO.File]::ReadAllText($taskLocal)
foreach ($taskProperty in @(@('flutter.buildMode','release'),@('flutter.versionName','1.0.0'),@('flutter.versionCode','6'))) {
    $taskPattern = '(?m)^' + [regex]::Escape($taskProperty[0]) + '=.*$'
    if ($taskLocalText -match $taskPattern) {
        $taskLocalText = [regex]::Replace($taskLocalText,$taskPattern,($taskProperty[0]+'='+$taskProperty[1]))
    } else { $taskLocalText += "`n" + $taskProperty[0] + '=' + $taskProperty[1] + "`n" }
}
[IO.File]::WriteAllText($taskLocal,$taskLocalText,[Text.UTF8Encoding]::new($false))
$taskCommand = '.\android\gradlew.bat -p android -q -Ptarget-platform=android-arm,android-arm64,android-x64 -Ptarget=lib/main.dart -Pbase-application-name=android.app.Application -Pdart-obfuscation=false -Ptrack-widget-creation=false -Ptree-shake-icons=true :app:assembleRelease -x :app:uploadCrashlyticsMappingFileRelease'
$taskStart = [DateTimeOffset]::UtcNow
$taskWatch = [Diagnostics.Stopwatch]::StartNew()
$taskProcess = Start-Process -FilePath $env:ComSpec -ArgumentList @('/d','/c',$taskCommand) -WorkingDirectory $taskRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $taskEvidence 'build.stdout.log') -RedirectStandardError (Join-Path $taskEvidence 'build.stderr.log')
$taskTimeout = $false
$taskNextProgress = 30
while (-not $taskProcess.WaitForExit(1000)) {
    if ($taskWatch.Elapsed.TotalSeconds -ge 1200) {
        $taskTimeout = $true
        $taskProcess.Kill($true)
        $taskProcess.WaitForExit()
        break
    }
    if ($taskWatch.Elapsed.TotalSeconds -ge $taskNextProgress) {
        Write-Output "Release build running: $([int]$taskWatch.Elapsed.TotalSeconds)s"
        $taskNextProgress += 30
    }
}
$taskProcess.Refresh()
$taskExit = if ($taskTimeout) {124} else {$taskProcess.ExitCode}
$taskMutations = @($taskSnapshot | Where-Object {(Get-FileHash -Algorithm SHA256 -LiteralPath $_.path).Hash.ToLowerInvariant() -ne $_.sha256})
$taskResult = [ordered]@{command=$taskCommand;startedAtUtc=$taskStart.ToString('o');finishedAtUtc=[DateTimeOffset]::UtcNow.ToString('o');durationMs=$taskWatch.ElapsedMilliseconds;exitCode=$taskExit;timedOut=$taskTimeout;sourceFiles=$taskSnapshot.Count;sourceUnchanged=($taskMutations.Count -eq 0)}
$taskResult | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $taskEvidence 'build-result.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $taskEvidence 'build.stdout.log') -Tail 8
Get-Content -LiteralPath (Join-Path $taskEvidence 'build.stderr.log') -Tail 8
$taskResult | ConvertTo-Json
if ($taskMutations.Count -gt 0) { throw 'Build mutated tracked source inputs.' }
exit $taskExit
