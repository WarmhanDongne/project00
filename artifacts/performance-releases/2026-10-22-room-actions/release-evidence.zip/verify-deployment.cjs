const {execFileSync} = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');
const root = 'C:/workspace/git/project00';
const output = execFileSync(process.execPath, [
  path.join(root, 'functions/node_modules/firebase-tools/lib/bin/firebase.js'),
  'functions:list', '--project', 'project0000-ec01e', '--json', '--non-interactive',
], {cwd: root, encoding: 'utf8', maxBuffer: 10 * 1024 * 1024, stdio: ['ignore', 'pipe', 'pipe']});
const response = JSON.parse(output);
const wanted = new Set(['createRealtimeRoom', 'removeRealtimeRoomPlayer', 'closeRoom']);
const rows = response.result;
const selected = rows.filter(row => wanted.has(row.id) || wanted.has(row.entryPoint)).map(row => ({
  name: row.id, entryPoint: row.entryPoint, region: row.region,
  runtime: row.runtime, platform: row.platform, state: row.state, sourceHash: row.hash,
}));
if (selected.length !== 3) {
  console.log(JSON.stringify({status: 'INCOMPLETE', count: rows.length, roomFunctionNames: rows.map(row => row.id).filter(id => /room/i.test(id))}));
  process.exit(1);
}
const record = {project: 'project0000-ec01e', deployExitCode: 0, metadataExitCode: 0, verifiedAtUtc: new Date().toISOString(), functions: selected};
fs.writeFileSync(path.join(__dirname, 'deployment-result.json'), JSON.stringify(record, null, 2));
console.log(JSON.stringify(record, null, 2));
if (selected.some(row => row.region !== 'asia-northeast3' || row.runtime !== 'nodejs22' || row.state !== 'ACTIVE')) process.exit(1);
